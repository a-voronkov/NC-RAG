<?php
declare(strict_types=1);

return [
    'routes' => [
        ['name' => 'settings#save', 'url' => '/settings/save', 'verb' => 'POST'],
    ],
];

