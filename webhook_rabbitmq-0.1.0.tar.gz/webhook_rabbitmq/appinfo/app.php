<?php
declare(strict_types=1);

\OC::$server->query(\OCA\WebhookRabbitMQ\AppInfo\Application::class);

